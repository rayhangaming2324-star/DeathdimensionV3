# DeathDimension V3

Plugin source untuk Paper 1.21.11 dengan Java 21.

## Fitur
- Cinematic saat menerima damage mematikan: title KAMU MATI, suara, blindness, levitation, partikel Soul/Portal, aura ungu-biru, dan efek petir visual (tanpa damage tambahan).
- Teleport ke world `DeathDimension`.
- Hukuman default 3 jam dan tetap berjalan saat pemain offline.
- Pemain dikembalikan ke spawn world `world` setelah waktu habis.
- Perintah `/dd status`, `/dd reload`, `/dd release <player>`.

## Persiapan
1. Pastikan server menggunakan Paper 1.21.11 dan Java 21.
2. Pastikan world bernama `DeathDimension` sudah tersedia. Plugin ini tidak membuat world baru.
3. Pastikan world utama bernama `world`, atau ubah `config.yml`.
4. Build source dengan Maven: `mvn clean package`.
5. Ambil JAR hasil build dari folder `target/` dan pasang ke folder `plugins/`.
6. Restart server.

## Perintah
- `/dd status` - cek sisa hukuman.
- `/dd reload` - muat ulang config (OP).
- `/dd release <player>` - bebaskan pemain (OP).

## Catatan pengujian
Ini adalah source awal V3. Uji di server cadangan terlebih dahulu. Periksa nama world, efek cinematic, teleport, timer offline, dan kompatibilitas API Paper sebelum digunakan di server utama.
