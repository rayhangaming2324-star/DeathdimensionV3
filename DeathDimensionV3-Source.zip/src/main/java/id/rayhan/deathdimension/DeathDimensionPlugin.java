package id.rayhan.deathdimension;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.io.File;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public final class DeathDimensionPlugin extends JavaPlugin implements Listener {
    private File dataFile;
    private YamlConfiguration data;
    private final Set<UUID> cinematic = new HashSet<>();
    private final Set<UUID> protectedPlayers = new HashSet<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        dataFile = new File(getDataFolder(), "data.yml");
        if (!dataFile.exists()) {
            try {
                getDataFolder().mkdirs();
                dataFile.createNewFile();
            } catch (IOException ex) {
                getLogger().severe("Tidak bisa membuat data.yml: " + ex.getMessage());
            }
        }
        data = YamlConfiguration.loadConfiguration(dataFile);
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("DeathDimension V3 aktif.");
        for (Player player : Bukkit.getOnlinePlayers()) {
            enforcePunishment(player);
        }
    }

    @Override
    public void onDisable() {
        saveData();
    }

    @EventHandler
    public void onLethalDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        if (isPunished(player.getUniqueId())) {
            event.setCancelled(true);
            return;
        }
        if (cinematic.contains(player.getUniqueId())) {
            event.setCancelled(true);
            return;
        }
        if (event.getFinalDamage() >= player.getHealth()) {
            event.setCancelled(true);
            beginDeathSequence(player);
        }
    }

    private void beginDeathSequence(Player player) {
        UUID id = player.getUniqueId();
        if (!cinematic.add(id)) return;

        player.setHealth(Math.max(1.0, Math.min(player.getHealth(), 1.0)));
        player.setInvulnerable(true);
        protectedPlayers.add(id);
        player.setVelocity(new Vector(0, 0.32, 0));
        player.setSwimming(true);

        player.sendTitle(color(getConfig().getString("death.title", "&c&lKAMU MATI")),
                color(getConfig().getString("death.subtitle", "&7Jiwamu telah dibawa ke dimensi lain...")),
                0, 65, 10);
        player.playSound(player.getLocation(), Sound.ENTITY_WARDEN_DEATH,
                (float) getConfig().getDouble("death.sound-volume", 1.4),
                (float) getConfig().getDouble("death.sound-pitch", 0.7));

        if (getConfig().getBoolean("effects.blindness", true)) {
            player.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 100, 1, false, false, false));
        }
        if (getConfig().getBoolean("effects.levitation", true)) {
            player.addPotionEffect(new PotionEffect(PotionEffectType.LEVITATION, 65, 0, false, false, true));
        }

        new BukkitRunnable() {
            int ticks = 0;
            @Override public void run() {
                if (!player.isOnline() || !cinematic.contains(id)) {
                    cancel();
                    return;
                }
                Location at = player.getLocation().add(0, 0.8, 0);
                if (getConfig().getBoolean("effects.particles", true)) {
                    player.getWorld().spawnParticle(Particle.SOUL, at, 8, 0.45, 0.6, 0.45, 0.015);
                    player.getWorld().spawnParticle(Particle.PORTAL, at, 12, 0.5, 0.7, 0.5, 0.15);
                    if (getConfig().getBoolean("effects.blue-purple-aura", true)) {
                        player.getWorld().spawnParticle(Particle.WITCH, at, 5, 0.35, 0.45, 0.35, 0.02);
                        player.getWorld().spawnParticle(Particle.ENCHANT, at, 10, 0.4, 0.6, 0.4, 0.4);
                    }
                }
                if (ticks == 20 && getConfig().getBoolean("effects.lightning-visual", true)) {
                    player.getWorld().strikeLightningEffect(player.getLocation());
                }
                ticks += 5;
                if (ticks >= getConfig().getInt("death.cinematic-seconds", 4) * 20) {
                    cancel();
                    sendToDeathDimension(player);
                }
            }
        }.runTaskTimer(this, 0L, 5L);
    }

    private void sendToDeathDimension(Player player) {
        UUID id = player.getUniqueId();
        World destination = Bukkit.getWorld(getConfig().getString("worlds.death-dimension", "DeathDimension"));
        if (destination == null) {
            destination = Bukkit.getWorld(getConfig().getString("worlds.return-world", "world"));
            getLogger().warning("World DeathDimension tidak ditemukan. Pastikan world tersebut sudah tersedia.");
        }
        if (destination != null) {
            player.teleport(destination.getSpawnLocation());
        }
        player.setSwimming(false);
        player.setInvulnerable(true);
        long duration = getConfig().getLong("death.punishment-seconds", 10800);
        data.set("players." + id, System.currentTimeMillis() + duration * 1000L);
        saveData();
        cinematic.remove(id);
        player.sendMessage(color(getConfig().getString("messages.prefix", "&8[&5DeathDimension&8] "))
                + color(getConfig().getString("messages.sent", "&cKamu telah memasuki Death Dimension!")));
        player.playSound(player.getLocation(), Sound.BLOCK_PORTAL_TRAVEL, 1.0f, 0.65f);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Bukkit.getScheduler().runTaskLater(this, () -> enforcePunishment(event.getPlayer()), 10L);
    }

    private void enforcePunishment(Player player) {
        UUID id = player.getUniqueId();
        long end = data.getLong("players." + id, 0L);
        if (end <= 0L) return;
        if (System.currentTimeMillis() >= end) {
            release(player, false);
            return;
        }
        World world = Bukkit.getWorld(getConfig().getString("worlds.death-dimension", "DeathDimension"));
        if (world != null && (player.getWorld() != world)) player.teleport(world.getSpawnLocation());
        player.setInvulnerable(true);
        protectedPlayers.add(id);
        player.sendMessage(color(getConfig().getString("messages.prefix", "&8[&5DeathDimension&8] "))
                + color(getConfig().getString("messages.remaining", "&eWaktu hukuman tersisa: &f%time%")
                .replace("%time%", formatDuration(end - System.currentTimeMillis()))));
        startCountdown(player);
    }

    private void startCountdown(Player player) {
        UUID id = player.getUniqueId();
        new BukkitRunnable() {
            @Override public void run() {
                if (!player.isOnline()) {
                    cancel();
                    return;
                }
                long end = data.getLong("players." + id, 0L);
                if (end <= 0L || System.currentTimeMillis() >= end) {
                    cancel();
                    release(player, false);
                }
            }
        }.runTaskTimer(this, 20L, 20L);
    }

    private void release(Player player, boolean admin) {
        UUID id = player.getUniqueId();
        data.set("players." + id, null);
        saveData();
        player.setInvulnerable(false);
        protectedPlayers.remove(id);
        World world = Bukkit.getWorld(getConfig().getString("worlds.return-world", "world"));
        if (world != null) player.teleport(world.getSpawnLocation());
        player.removePotionEffect(PotionEffectType.BLINDNESS);
        player.removePotionEffect(PotionEffectType.LEVITATION);
        player.setSwimming(false);
        player.sendMessage(color(getConfig().getString("messages.prefix", "&8[&5DeathDimension&8] "))
                + color(getConfig().getString("messages.released", "&aKamu telah dikembalikan ke dunia utama.")));
    }

    private boolean isPunished(UUID id) {
        long end = data.getLong("players." + id, 0L);
        return end > System.currentTimeMillis();
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        // Timestamp hukuman disimpan, jadi waktu tetap berjalan saat pemain offline.
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!command.getName().equalsIgnoreCase("dd")) return false;
        if (args.length == 0 || args[0].equalsIgnoreCase("status")) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("Gunakan /dd reload atau /dd release <player>.");
                return true;
            }
            long end = data.getLong("players." + player.getUniqueId(), 0L);
            if (end <= System.currentTimeMillis()) {
                player.sendMessage(color(getConfig().getString("messages.no-punishment", "&aKamu tidak sedang menjalani hukuman.")));
            } else {
                player.sendMessage(color(getConfig().getString("messages.remaining", "&eWaktu hukuman tersisa: &f%time%")
                        .replace("%time%", formatDuration(end - System.currentTimeMillis()))));
            }
            return true;
        }
        if (!sender.hasPermission("deathdimension.admin")) {
            sender.sendMessage(color(getConfig().getString("messages.no-permission", "&cKamu tidak memiliki izin.")));
            return true;
        }
        if (args[0].equalsIgnoreCase("reload")) {
            reloadConfig();
            sender.sendMessage(color("&aDeathDimension config berhasil dimuat ulang."));
            return true;
        }
        if (args[0].equalsIgnoreCase("release") && args.length >= 2) {
            Player target = Bukkit.getPlayerExact(args[1]);
            if (target == null) {
                sender.sendMessage(color(getConfig().getString("messages.player-not-found", "&cPemain tidak ditemukan.")));
                return true;
            }
            release(target, true);
            sender.sendMessage(color(getConfig().getString("messages.admin-release", "&aPemain %player% berhasil dibebaskan.")
                    .replace("%player%", target.getName())));
            return true;
        }
        sender.sendMessage(color("&ePerintah: /dd status, /dd reload, /dd release <player>"));
        return true;
    }

    private void saveData() {
        if (data == null || dataFile == null) return;
        try {
            data.save(dataFile);
        } catch (IOException ex) {
            getLogger().severe("Gagal menyimpan data.yml: " + ex.getMessage());
        }
    }

    private String formatDuration(long millis) {
        long seconds = Math.max(0, millis / 1000L);
        long hours = seconds / 3600;
        long minutes = (seconds % 3600) / 60;
        long secs = seconds % 60;
        return String.format("%02d:%02d:%02d", hours, minutes, secs);
    }

    private String color(String text) {
        return ChatColor.translateAlternateColorCodes('&', text == null ? "" : text);
    }
}
